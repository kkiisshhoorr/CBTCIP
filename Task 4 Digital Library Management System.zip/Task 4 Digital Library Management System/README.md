# OIBSIP_Library_Management_System

# Database:
<img width="521" alt="Screenshot 2023-09-08 at 8 01 02 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/a72ada8d-b010-4246-8ee9-4d3245433edc">
<img width="556" alt="Screenshot 2023-09-08 at 8 01 12 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/868c03c1-a582-4076-9b20-5faa662e8dbe">

# Library System
# Login
<img width="999" alt="Screenshot 2023-09-08 at 9 40 34 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/4b556cb2-35a3-4ad7-931e-93e6a715cb46">

# Main Menu
<img width="999" alt="Screenshot 2023-09-08 at 8 39 15 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/8d48dab9-50f7-47f7-8201-9f5aad462f9e">

# Add / Search Students
<img width="999" alt="Screenshot 2023-09-08 at 8 05 44 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/c612af9e-9611-416a-ae27-a24c801b1a26">

# Existing Students
<img width="999" alt="Screenshot 2023-09-08 at 8 06 17 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/9bd38400-6d14-44ff-b7cf-08a248a353b9">

# Add Student
<img width="999" alt="Screenshot 2023-09-08 at 8 12 01 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/2c4b456c-db15-4e41-8e4e-86dd8d04a422">

# Student Added
<img width="999" alt="Screenshot 2023-09-08 at 8 11 03 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/0d3d6197-2f3a-4cab-b76a-5f0a807d86fd">

# Existing Students List
<img width="999" alt="Screenshot 2023-09-08 at 8 11 21 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/14fc83aa-255d-4e5e-9196-19dcf2ca4f04">

# Search Student to delete
<img width="999" alt="Screenshot 2023-09-08 at 8 12 22 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/20513417-6a6e-42be-8c84-2067e114a891">

# Student Found
<img width="999" alt="Screenshot 2023-09-08 at 8 07 01 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/863895d1-498a-476b-bcc1-3764dc933188">

# Confirm Delete
<img width="999" alt="Screenshot 2023-09-08 at 8 29 08 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/271836cd-d4e6-437c-97c2-1869b5a4c654">

# Student Deleted
<img width="999" alt="Screenshot 2023-09-08 at 8 29 25 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/415ac989-3f3b-4210-96f9-00c58c510b04">

# Student List
<img width="999" alt="Screenshot 2023-09-08 at 8 29 48 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/e02d2f24-62ca-4b28-b5da-07bc95713175">

# Add / Search Books
<img width="999" alt="Screenshot 2023-09-08 at 8 39 01 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/10a737be-15e3-4a53-8702-9e5f8fe72522">

# Existing Books
<img width="999" alt="Screenshot 2023-09-08 at 8 24 56 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/430ef07e-c41c-45b2-bec2-beabaefa3c34">

# Add Book
<img width="999" alt="Screenshot 2023-09-08 at 8 47 58 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/14ca2c39-a39d-4a19-af67-bba4ff810fad">

# Book Added
<img width="999" alt="Screenshot 2023-09-08 at 8 48 13 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/b2b16029-2c1b-47e5-93fa-933e1a0f1408">

# Book List
<img width="999" alt="Screenshot 2023-09-08 at 8 52 14 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/08b1c000-1b87-4f73-9c89-86588e59e0e6">

# Search Book
<img width="999" alt="Screenshot 2023-09-08 at 8 48 41 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/f59feb34-0ddb-4788-bc0f-33f863a52f8e">

# Book Found
<img width="999" alt="Screenshot 2023-09-08 at 8 51 51 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/5f4aa8fc-4936-43bc-bbfd-a1508404e945">

# Delete Book
<img width="999" alt="Screenshot 2023-09-08 at 9 02 59 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/74c1ea2b-da59-48a6-9e44-fbada01dc7f9">

# Book Deleted
<img width="999" alt="Screenshot 2023-09-08 at 9 03 11 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/04743a8c-d252-421e-ba6e-2fa7fb03d5c3">

# Book List 
<img width="999" alt="Screenshot 2023-09-08 at 8 24 56 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/430ef07e-c41c-45b2-bec2-beabaefa3c34">

# Issue Book
<img width="999" alt="Screenshot 2023-09-08 at 10 30 51 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/2a24d7f9-f166-4d4e-8e4a-8a5d57539876">

# Book Issued
<img width="999" alt="Screenshot 2023-09-08 at 10 30 38 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/a22044ad-d13f-4010-a57b-b5067aab9c1d">

# Issued Books Data
<img width="999" alt="Screenshot 2023-09-08 at 10 31 11 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/3dc443f6-3ac1-4862-9b69-49436e0b0a8f">

# Book Return 
<img width="999" alt="Screenshot 2023-09-08 at 10 34 47 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/d2e536f8-61dd-4856-b8bf-3a872b44e352">

# Confirm Book Return
<img width="999" alt="Screenshot 2023-09-08 at 10 35 11 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/33782942-3d8e-4386-933e-21157cc63780">

# Book Returned
<img width="999" alt="Screenshot 2023-09-08 at 10 35 20 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/396f0bff-aa70-47b4-b789-0e4a643bccd1">

# Book Returned Data
<img width="999" alt="Screenshot 2023-09-08 at 11 00 14 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/fc2b6ace-67dc-47db-9698-84f1dc077f4c">

# Issued Books Data
Student who returned the book now removed from issued books data
<img width="999" alt="Screenshot 2023-09-08 at 10 35 47 PM" src="https://github.com/HarshAgarwal1102/OIBSIP_Library_Management_System/assets/117922914/e1adce16-650e-4c49-ba55-a90a604e969f">
